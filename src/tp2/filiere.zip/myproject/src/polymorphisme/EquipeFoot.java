package polymorphisme;

import tp2.Personne;
import tp2.Etudiant;
import java.util.ArrayList;


public class EquipeFoot{
	 String nom;
	 ArrayList<Personne> Joueurs;
	 ArrayList<Etudiant> Etudiant;
	 
	 public EquipeFoot(ArrayList<tp2.Etudiant> etudiant) {
		super();
		Etudiant = etudiant;
	}
	 
	 public EquipeFoot(String nom) {
		 this.nom= nom;
		 this.Joueurs=new ArrayList<>();
	 }
	 public EquipeFoot(String nom, ArrayList<Personne> joueurs) {
		super();
		this.nom = nom;
		Joueurs = joueurs;
	 }
	 public EquipeFoot(String nom,Personne ...tab) {
		 
		 super();
		 this.nom=nom;
		 //this.Joueurs=new ArrayList<Personne>(Arrays.asList(tab));
		 for(Personne p:tab) {
			 if(this.Joueurs.contains(p)==false)
				 this.Joueurs.add(p);
		 }
	 }
	 public String getNom() {
		 return nom;
	 }
	 public void setNom(String nom) {
		 this.nom=nom;
	 }
	 public ArrayList<Personne> getJoueurs(){
		 return Joueurs;
	 }
	 
	 
	 
	 
	 //constructeur
	 
	 
}
